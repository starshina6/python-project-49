#!/usr/bin/env python3
from brain_games.even  import chek_even


def main():
    print('Welcome to the Brain Games!')    
    chek_even(3)


if __name__ == '__main__':
    main()
