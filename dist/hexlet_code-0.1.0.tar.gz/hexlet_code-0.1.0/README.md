### Hexlet tests and linter status:
[![Actions Status](https://github.com/starshina6/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/starshina6/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/8f7d6ab75e2a8de1222c/maintainability)](https://codeclimate.com/github/starshina6/python-project-49/maintainability)
https://asciinema.org/a/10vaXt3vtnS0Pe369XtEYNjsF
